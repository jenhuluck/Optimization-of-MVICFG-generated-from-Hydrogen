#include <stdio.h>
int main() {
	int a, b, c;
	scanf("%d %d", &a, &b);
	c = a + b + 30;
	c += 10;
	if(c > 20){
		c += a;
	}
	else{
		c += b;
	}
	c += 10;
	return 0;
}