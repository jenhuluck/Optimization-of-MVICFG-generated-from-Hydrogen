#include <stdio.h>
int main () {
   int a = 10;
   int b = 20;
   int c = 30;
   int sum = a + b + c;  
   return sum;
}
