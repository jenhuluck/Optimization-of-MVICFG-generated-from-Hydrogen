#include <stdio.h>
int main () {
   int a = 10;
   int b = 20;
   int sum = a + b + 30;  
   return sum;
}
