int rand_num(int size) {
	static int *numArr = NULL;
	static int numNums = 0;
	int i, n;
	
	if (size == -22) {
		free(numArr);
		return FREED_RAND;
	}
	
	if (size >= 0) {
		if (numArr != NULL)
			free(numArr);
		
		if ((numArr = (int *) malloc(sizeof(int) * size)) == NULL)
			return ERR_NO_MEM;
		
		for (i = 0; i < size; ++i)
			numArr[i] = i;
		
		numNums = size;
	}
	
	if (numNums == 0)
		return ERR_NO_NUM;
	
	n = rand() % numNums;
	i = numArr[n];
	numArr[n] = numArr[numNums - 1];
	numNums--;
	
	if (numNums == 0) {
		free(numArr);
		numArr = 0;
	}
	
	return i;
}