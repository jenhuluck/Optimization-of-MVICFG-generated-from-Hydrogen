#include <stdio.h>

int get_sign(int x) {
  if (x == 0)
     return 0;
  
  if (x < 0)
     return -1;
  else 
     return 1;
} 

int main() {

  char* crash =0;
  int x, a;

  scanf("%d", &x);

  a = get_sign(x);
  if(a == 0)
    printf("Is zero\n");
  if(a == 1){
    printf("%s\n",crash); //crash
    printf("Is positive\n");
  }
  else
    printf("Is negative\n");
}