#include <stdio.h>
int main() {
	int a, b, c;
	scanf("%d %d", &a, &b);
	c = a + b;
	if(c > 10){
		c += a;
	}
	else if(c < 0){
		c += a;
		c += b;
	}
	return 0;
}